import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type Question } from "@shared/schema";

// Helper to shuffle array (Fisher-Yates)
function shuffleArray<T>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

export function useQuestions() {
  return useQuery({
    queryKey: [api.questions.list.path],
    queryFn: async () => {
      const res = await fetch(api.questions.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch questions");
      return api.questions.list.responses[200].parse(await res.json());
    },
  });
}

export function useChapterQuestions(chapterId: number) {
  return useQuery({
    queryKey: [api.questions.getByChapter.path, chapterId],
    queryFn: async () => {
      const url = buildUrl(api.questions.getByChapter.path, { chapterId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch chapter questions");
      const data = api.questions.getByChapter.responses[200].parse(await res.json());
      
      // Shuffle questions and options for better quiz experience
      // We parse the JSON options here if they come as strings, but schema says jsonb array
      // Assuming options are string[]
      
      const shuffledQuestions = shuffleArray(data).map(q => ({
        ...q,
        options: shuffleArray(q.options as string[])
      }));

      // Limit to 10-15 questions per session if many exist
      return shuffledQuestions.slice(0, 15);
    },
    enabled: !!chapterId && !isNaN(chapterId),
  });
}

// Static data for chapter metadata (since we don't have a chapters table in the provided schema)
export const CHAPTERS = [
  { id: 1, name: "Real Numbers", icon: "Calculator" },
  { id: 2, name: "Polynomials", icon: "FunctionSquare" },
  { id: 3, name: "Pair of Linear Equations", icon: "Equal" },
  { id: 4, name: "Quadratic Equations", icon: "Superscript" },
  { id: 5, name: "Arithmetic Progressions", icon: "ListOrdered" },
  { id: 6, name: "Triangles", icon: "Triangle" },
  { id: 7, name: "Coordinate Geometry", icon: "Axis3d" },
  { id: 8, name: "Introduction to Trigonometry", icon: "Pi" },
  { id: 9, name: "Applications of Trigonometry", icon: "Mountain" },
  { id: 10, name: "Circles", icon: "Circle" },
  { id: 11, name: "Areas Related to Circles", icon: "Disc" },
  { id: 12, name: "Surface Areas and Volumes", icon: "Box" },
  { id: 13, name: "Statistics", icon: "BarChart3" },
  { id: 14, name: "Probability", icon: "Dices" },
];
