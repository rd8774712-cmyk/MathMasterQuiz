import { Link } from "wouter";
import { motion } from "framer-motion";
import { 
  Calculator, FunctionSquare, Equal, Superscript, ListOrdered, 
  Triangle, Axis3d, Pi, Mountain, Circle, Disc, Box, BarChart3, Dices, 
  Trophy, ArrowRight
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

// Map icon strings to components
const IconMap: Record<string, any> = {
  Calculator, FunctionSquare, Equal, Superscript, ListOrdered,
  Triangle, Axis3d, Pi, Mountain, Circle, Disc, Box, BarChart3, Dices
};

interface ChapterCardProps {
  id: number;
  name: string;
  iconName: string;
  highScore?: number;
}

export function ChapterCard({ id, name, iconName, highScore }: ChapterCardProps) {
  const Icon = IconMap[iconName] || Calculator;

  return (
    <motion.div
      whileHover={{ y: -5, scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      <Link href={`/quiz/${id}`} className="block h-full cursor-pointer group">
        <Card className="h-full overflow-hidden border-2 border-transparent hover:border-primary/20 hover:shadow-xl hover:shadow-primary/5 transition-all duration-300 bg-white/80 backdrop-blur-sm">
          <CardContent className="p-6 flex flex-col items-center text-center h-full relative">
            <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
              <span className="text-6xl font-black font-display text-primary">{id}</span>
            </div>
            
            <div className="mb-6 p-4 rounded-2xl bg-primary/5 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
              <Icon size={32} strokeWidth={2} />
            </div>
            
            <h3 className="text-lg font-bold font-display text-foreground mb-2 group-hover:text-primary transition-colors">
              {name}
            </h3>
            
            <div className="mt-auto w-full pt-4">
              {highScore !== undefined ? (
                <div className="flex items-center justify-center gap-2 text-sm font-medium text-amber-500 bg-amber-50 px-3 py-1.5 rounded-full border border-amber-100">
                  <Trophy size={14} />
                  <span>Best: {highScore}%</span>
                </div>
              ) : (
                <div className="flex items-center justify-center gap-1 text-sm font-medium text-muted-foreground group-hover:text-primary transition-colors">
                  Start Quiz <ArrowRight size={14} className="ml-1" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  );
}
