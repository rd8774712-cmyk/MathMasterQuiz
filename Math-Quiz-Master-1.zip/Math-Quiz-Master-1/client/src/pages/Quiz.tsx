import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useChapterQuestions, CHAPTERS } from "@/hooks/use-questions";
import { QuizProgressBar } from "@/components/QuizProgressBar";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Loader2, AlertCircle, ChevronRight, CheckCircle2, Home } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Quiz() {
  const [, params] = useRoute("/quiz/:chapterId");
  const [, setLocation] = useLocation();
  const chapterId = params ? parseInt(params.chapterId, 10) : 0;
  
  const { data: questions, isLoading, error } = useChapterQuestions(chapterId);
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const chapter = CHAPTERS.find(c => c.id === chapterId);

  // If we finish all questions, navigate to results
  const handleFinish = () => {
    setIsSubmitting(true);
    
    // Calculate score
    let correctCount = 0;
    const resultsData = questions!.map(q => {
      const userAnswer = answers[q.id];
      const isCorrect = userAnswer === q.correctAnswer;
      if (isCorrect) correctCount++;
      
      return {
        questionId: q.id,
        question: q.question,
        userAnswer,
        correctAnswer: q.correctAnswer,
        isCorrect
      };
    });

    const scorePercentage = Math.round((correctCount / questions!.length) * 100);

    // Save high score
    const currentHighScore = localStorage.getItem(`highscore_chapter_${chapterId}`);
    if (!currentHighScore || scorePercentage > parseInt(currentHighScore, 10)) {
      localStorage.setItem(`highscore_chapter_${chapterId}`, scorePercentage.toString());
    }

    // Pass results to result page via state (mocking by using localStorage for simplicity in this demo)
    localStorage.setItem('last_quiz_results', JSON.stringify({
      chapterName: chapter?.name,
      chapterId,
      totalQuestions: questions!.length,
      correctCount,
      scorePercentage,
      details: resultsData
    }));

    // Artificial delay for UX
    setTimeout(() => {
      setLocation("/results");
    }, 800);
  };

  const handleNext = () => {
    if (questions && currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedOption(answers[questions[currentQuestionIndex + 1].id] || null);
    } else {
      handleFinish();
    }
  };

  const handleOptionSelect = (value: string) => {
    if (!questions) return;
    setSelectedOption(value);
    setAnswers(prev => ({
      ...prev,
      [questions[currentQuestionIndex].id]: value
    }));
  };

  useEffect(() => {
    if (questions && questions[currentQuestionIndex]) {
      // Restore answer if already answered (allows going back if we implemented back button)
      setSelectedOption(answers[questions[currentQuestionIndex].id] || null);
    }
  }, [currentQuestionIndex, questions]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
          <h2 className="text-xl font-bold text-foreground">Loading Quiz...</h2>
          <p className="text-muted-foreground mt-2">Preparing your questions</p>
        </div>
      </div>
    );
  }

  if (error || !questions || questions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="max-w-md w-full border-destructive/20 shadow-lg">
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 bg-destructive/10 rounded-full flex items-center justify-center mb-4">
              <AlertCircle className="h-6 w-6 text-destructive" />
            </div>
            <CardTitle className="text-destructive">Unable to Load Quiz</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-muted-foreground mb-6">
              We couldn't load the questions for this chapter. Please try again later.
            </p>
            <Button onClick={() => setLocation("/")} variant="outline">
              Return Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === questions.length - 1;

  return (
    <div className="min-h-screen bg-math-grid py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setLocation("/")}
            className="text-muted-foreground hover:text-foreground"
          >
            <Home className="w-4 h-4 mr-2" />
            Quit Quiz
          </Button>
          <div className="text-sm font-semibold px-3 py-1 bg-primary/10 text-primary rounded-full">
            {chapter?.name}
          </div>
        </div>

        <QuizProgressBar current={currentQuestionIndex + 1} total={questions.length} />

        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestionIndex}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="border-border shadow-xl overflow-hidden glass-panel">
              <CardContent className="p-6 md:p-8">
                <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8 font-display leading-tight">
                  {currentQuestion.question}
                </h2>

                <RadioGroup 
                  value={selectedOption || ""} 
                  onValueChange={handleOptionSelect}
                  className="space-y-4"
                >
                  {(currentQuestion.options as string[]).map((option, idx) => (
                    <div 
                      key={idx}
                      className={`relative flex items-center space-x-3 rounded-xl border-2 p-4 transition-all duration-200 cursor-pointer ${
                        selectedOption === option 
                          ? "border-primary bg-primary/5 shadow-md scale-[1.01]" 
                          : "border-border hover:border-primary/50 hover:bg-slate-50"
                      }`}
                      onClick={() => handleOptionSelect(option)}
                    >
                      <RadioGroupItem value={option} id={`option-${idx}`} className="border-2 border-primary text-primary" />
                      <Label 
                        htmlFor={`option-${idx}`} 
                        className="flex-1 cursor-pointer text-base md:text-lg font-medium text-foreground"
                      >
                        {option}
                      </Label>
                      {selectedOption === option && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="text-primary"
                        >
                          <CheckCircle2 size={20} />
                        </motion.div>
                      )}
                    </div>
                  ))}
                </RadioGroup>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        <div className="mt-8 flex justify-end">
          <Button 
            size="lg" 
            onClick={handleNext} 
            disabled={!selectedOption || isSubmitting}
            className="px-8 py-6 text-lg rounded-full shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-0.5 transition-all"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Calculating...
              </>
            ) : isLastQuestion ? (
              "Submit Quiz"
            ) : (
              <>
                Next Question <ChevronRight className="ml-2 h-5 w-5" />
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
