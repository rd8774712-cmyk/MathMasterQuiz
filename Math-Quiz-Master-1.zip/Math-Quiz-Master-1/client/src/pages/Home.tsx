import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { GraduationCap, Sparkles } from "lucide-react";
import { CHAPTERS } from "@/hooks/use-questions";
import { ChapterCard } from "@/components/ChapterCard";

export default function Home() {
  const [highScores, setHighScores] = useState<Record<number, number>>({});

  useEffect(() => {
    // Load high scores from localStorage
    const savedScores: Record<number, number> = {};
    CHAPTERS.forEach(chapter => {
      const score = localStorage.getItem(`highscore_chapter_${chapter.id}`);
      if (score) {
        savedScores[chapter.id] = parseInt(score, 10);
      }
    });
    setHighScores(savedScores);
  }, []);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05
      }
    }
  };

  return (
    <div className="min-h-screen bg-math-grid pb-20">
      {/* Hero Section */}
      <header className="relative bg-white border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="text-center md:text-left">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-4"
            >
              <Sparkles size={16} />
              <span>Class 10 CBSE / NCERT</span>
            </motion.div>
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-black font-display tracking-tight text-foreground mb-4"
            >
              Maths Master <span className="text-primary">Quiz</span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg text-muted-foreground max-w-xl mx-auto md:mx-0 font-body leading-relaxed"
            >
              Master your syllabus one chapter at a time. Practice with high-quality MCQs designed to boost your exam confidence.
            </motion.p>
          </div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="relative hidden md:block"
          >
            <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full transform -translate-y-4"></div>
            <GraduationCap size={160} className="text-primary relative z-10 drop-shadow-2xl" strokeWidth={1.5} />
          </motion.div>
        </div>
      </header>

      {/* Chapters Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-center gap-4 mb-8">
          <h2 className="text-2xl font-bold font-display">Select a Chapter</h2>
          <div className="h-px flex-1 bg-border"></div>
        </div>

        <motion.div 
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        >
          {CHAPTERS.map((chapter) => (
            <ChapterCard 
              key={chapter.id}
              id={chapter.id}
              name={chapter.name}
              iconName={chapter.icon}
              highScore={highScores[chapter.id]}
            />
          ))}
        </motion.div>
      </main>
      
      <footer className="max-w-7xl mx-auto px-4 py-8 text-center text-muted-foreground text-sm border-t border-border/40 mt-auto">
        <p>© 2024 Maths Master Quiz App. Aligned with Class 10 Syllabus.</p>
      </footer>
    </div>
  );
}
