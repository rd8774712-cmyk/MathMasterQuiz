import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2, XCircle, RefreshCw, Home, Trophy, BarChart3 } from "lucide-react";
import confetti from "canvas-confetti"; // Just standard import, assuming browser env handles it or polyfill

interface ResultDetail {
  questionId: number;
  question: string;
  userAnswer: string;
  correctAnswer: string;
  isCorrect: boolean;
}

interface QuizResult {
  chapterName: string;
  chapterId: number;
  totalQuestions: number;
  correctCount: number;
  scorePercentage: number;
  details: ResultDetail[];
}

export default function Results() {
  const [, setLocation] = useLocation();
  const [results, setResults] = useState<QuizResult | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem('last_quiz_results');
    if (stored) {
      const parsed = JSON.parse(stored);
      setResults(parsed);

      // Trigger confetti if score is good
      if (parsed.scorePercentage >= 70) {
        const duration = 3 * 1000;
        const animationEnd = Date.now() + duration;
        const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

        const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

        const interval: any = setInterval(function() {
          const timeLeft = animationEnd - Date.now();

          if (timeLeft <= 0) {
            return clearInterval(interval);
          }

          const particleCount = 50 * (timeLeft / duration);
          // since particles fall down, start a bit higher than random
          (window as any).confetti && (window as any).confetti(Object.assign({}, defaults, { particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } }));
          (window as any).confetti && (window as any).confetti(Object.assign({}, defaults, { particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } }));
        }, 250);
      }
    } else {
      setLocation("/");
    }
  }, []);

  if (!results) return null;

  const getGrade = (percentage: number) => {
    if (percentage >= 90) return { label: "Excellent!", color: "text-green-600", bg: "bg-green-100" };
    if (percentage >= 70) return { label: "Great Job!", color: "text-blue-600", bg: "bg-blue-100" };
    if (percentage >= 50) return { label: "Good Effort", color: "text-amber-600", bg: "bg-amber-100" };
    return { label: "Keep Practicing", color: "text-red-600", bg: "bg-red-100" };
  };

  const grade = getGrade(results.scorePercentage);

  return (
    <div className="min-h-screen bg-math-grid py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center justify-center p-4 bg-white rounded-full shadow-lg mb-6">
            <Trophy className={`w-12 h-12 ${grade.color}`} />
          </div>
          <h1 className="text-4xl md:text-5xl font-black font-display mb-2">{grade.label}</h1>
          <p className="text-xl text-muted-foreground">
            You scored <span className={`font-bold ${grade.color}`}>{results.scorePercentage}%</span> on {results.chapterName}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="bg-white/80 backdrop-blur border-none shadow-lg">
            <CardContent className="p-6 flex flex-col items-center justify-center text-center h-full">
              <div className="text-sm text-muted-foreground uppercase font-bold tracking-wider mb-1">Total Score</div>
              <div className="text-4xl font-black text-primary">{results.correctCount}/{results.totalQuestions}</div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/80 backdrop-blur border-none shadow-lg">
            <CardContent className="p-6 flex flex-col items-center justify-center text-center h-full">
              <div className="text-sm text-muted-foreground uppercase font-bold tracking-wider mb-1">Correct</div>
              <div className="text-4xl font-black text-green-600">{results.correctCount}</div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur border-none shadow-lg">
            <CardContent className="p-6 flex flex-col items-center justify-center text-center h-full">
              <div className="text-sm text-muted-foreground uppercase font-bold tracking-wider mb-1">Incorrect</div>
              <div className="text-4xl font-black text-red-500">{results.totalQuestions - results.correctCount}</div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <h3 className="text-2xl font-bold font-display ml-1">Detailed Review</h3>
          
          {results.details.map((detail, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.05 }}
            >
              <Card className={`overflow-hidden border-l-4 ${detail.isCorrect ? 'border-l-green-500' : 'border-l-red-500'}`}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 mt-1">
                      {detail.isCorrect ? (
                        <CheckCircle2 className="w-6 h-6 text-green-500" />
                      ) : (
                        <XCircle className="w-6 h-6 text-red-500" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-lg text-foreground mb-4">{detail.question}</p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className={`p-3 rounded-lg border ${detail.isCorrect ? 'bg-green-50 border-green-100' : 'bg-red-50 border-red-100'}`}>
                          <span className="text-xs font-bold uppercase block mb-1 opacity-70">Your Answer</span>
                          <span className={detail.isCorrect ? 'text-green-800 font-medium' : 'text-red-800 font-medium'}>
                            {detail.userAnswer}
                          </span>
                        </div>
                        
                        {!detail.isCorrect && (
                          <div className="p-3 rounded-lg border bg-green-50 border-green-100">
                            <span className="text-xs font-bold uppercase block mb-1 opacity-70 text-green-700">Correct Answer</span>
                            <span className="text-green-800 font-medium">
                              {detail.correctAnswer}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 flex flex-col sm:flex-row justify-center gap-4">
          <Button 
            size="lg" 
            variant="outline" 
            onClick={() => setLocation("/")}
            className="border-2 rounded-full px-8 py-6 text-lg hover:bg-secondary/80"
          >
            <Home className="mr-2 w-5 h-5" /> Back to Home
          </Button>
          
          <Button 
            size="lg"
            onClick={() => setLocation(`/quiz/${results.chapterId}`)}
            className="rounded-full px-8 py-6 text-lg shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all"
          >
            <RefreshCw className="mr-2 w-5 h-5" /> Try Again
          </Button>
        </div>
      </div>
    </div>
  );
}
